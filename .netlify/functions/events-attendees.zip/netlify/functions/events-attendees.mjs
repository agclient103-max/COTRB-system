
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions-lib/db.js
import { getDatabase } from "@netlify/database";
var cached = null;
function getDb() {
  if (!cached) {
    cached = getDatabase();
  }
  return cached;
}

// netlify/functions-lib/auth.js
import { getUser } from "@netlify/identity";

// src/data/roles.js
var ROLES = {
  SUPER_ADMIN: "SUPER_ADMIN",
  ADMIN: "ADMIN",
  COUNCIL_MEMBER: "COUNCIL_MEMBER",
  TREASURER: "TREASURER",
  CLERGY: "CLERGY",
  MINISTRY_COORDINATOR: "MINISTRY_COORDINATOR",
  STAFF: "STAFF",
  MEMBER: "MEMBER",
  GUEST: "GUEST"
};
var ROLE_LABELS = {
  [ROLES.SUPER_ADMIN]: "Super Admin",
  [ROLES.ADMIN]: "Church Administrator",
  [ROLES.COUNCIL_MEMBER]: "Council Member",
  [ROLES.TREASURER]: "Treasurer",
  [ROLES.CLERGY]: "Clergy / Vicar",
  [ROLES.MINISTRY_COORDINATOR]: "Ministry Coordinator",
  [ROLES.STAFF]: "Staff / Secretary",
  [ROLES.MEMBER]: "Member",
  [ROLES.GUEST]: "Guest"
};
var ACCESS_MATRIX = {
  documents: {
    [ROLES.SUPER_ADMIN]: "CRUD_APPROVE",
    [ROLES.ADMIN]: "CRUD",
    [ROLES.COUNCIL_MEMBER]: "READ_APPROVE",
    [ROLES.TREASURER]: "READ",
    [ROLES.CLERGY]: "CRUD_APPROVE",
    [ROLES.MINISTRY_COORDINATOR]: "CR_SCOPED",
    [ROLES.STAFF]: "CRU",
    [ROLES.MEMBER]: "NONE",
    [ROLES.GUEST]: "NONE"
  },
  ministry: {
    [ROLES.SUPER_ADMIN]: "CRUD",
    [ROLES.ADMIN]: "READ",
    [ROLES.COUNCIL_MEMBER]: "CRU",
    [ROLES.TREASURER]: "READ",
    [ROLES.CLERGY]: "CRUD",
    [ROLES.MINISTRY_COORDINATOR]: "CRUD_SCOPED",
    [ROLES.STAFF]: "READ",
    [ROLES.MEMBER]: "NONE",
    [ROLES.GUEST]: "NONE"
  },
  personnel: {
    [ROLES.SUPER_ADMIN]: "CRUD",
    [ROLES.ADMIN]: "CRUD",
    [ROLES.COUNCIL_MEMBER]: "READ",
    [ROLES.TREASURER]: "READ",
    [ROLES.CLERGY]: "CRU",
    [ROLES.MINISTRY_COORDINATOR]: "READ",
    [ROLES.STAFF]: "READ",
    [ROLES.MEMBER]: "NONE",
    [ROLES.GUEST]: "NONE"
  },
  financial: {
    [ROLES.SUPER_ADMIN]: "CRUD",
    [ROLES.ADMIN]: "CRUD",
    [ROLES.COUNCIL_MEMBER]: "READ",
    [ROLES.TREASURER]: "CRUD",
    [ROLES.CLERGY]: "READ",
    [ROLES.MINISTRY_COORDINATOR]: "READ",
    [ROLES.STAFF]: "READ",
    [ROLES.MEMBER]: "NONE",
    [ROLES.GUEST]: "NONE"
  },
  events: {
    [ROLES.SUPER_ADMIN]: "CRUD",
    [ROLES.ADMIN]: "CRUD",
    [ROLES.COUNCIL_MEMBER]: "CRU",
    [ROLES.TREASURER]: "READ",
    [ROLES.CLERGY]: "CRUD",
    [ROLES.MINISTRY_COORDINATOR]: "CRUD_SCOPED",
    [ROLES.STAFF]: "CR",
    [ROLES.MEMBER]: "READ",
    [ROLES.GUEST]: "READ"
  },
  reports: {
    [ROLES.SUPER_ADMIN]: "CRUD",
    [ROLES.ADMIN]: "CRUD",
    [ROLES.COUNCIL_MEMBER]: "READ",
    [ROLES.TREASURER]: "CRUD",
    [ROLES.CLERGY]: "READ",
    [ROLES.MINISTRY_COORDINATOR]: "READ_SCOPED",
    [ROLES.STAFF]: "READ",
    [ROLES.MEMBER]: "NONE",
    [ROLES.GUEST]: "NONE"
  },
  settings: {
    [ROLES.SUPER_ADMIN]: "CRUD",
    [ROLES.ADMIN]: "CRU",
    [ROLES.COUNCIL_MEMBER]: "NONE",
    [ROLES.TREASURER]: "NONE",
    [ROLES.CLERGY]: "READ",
    [ROLES.MINISTRY_COORDINATOR]: "NONE",
    [ROLES.STAFF]: "NONE",
    [ROLES.MEMBER]: "NONE",
    [ROLES.GUEST]: "NONE"
  }
};
var LEVEL_FLAGS = {
  NONE: [],
  READ: ["R"],
  READ_APPROVE: ["R", "APPROVE"],
  READ_SCOPED: ["R", "SCOPED"],
  CR: ["C", "R"],
  CR_SCOPED: ["C", "R", "SCOPED"],
  CRU: ["C", "R", "U"],
  CRUD: ["C", "R", "U", "D"],
  CRUD_SCOPED: ["C", "R", "U", "D", "SCOPED"],
  CRUD_APPROVE: ["C", "R", "U", "D", "APPROVE"]
};
function hasFlag(level, flag) {
  return (LEVEL_FLAGS[level] ?? []).includes(flag);
}
function hasModuleAccess(role, moduleKey) {
  const level = ACCESS_MATRIX[moduleKey]?.[role];
  return Boolean(level) && level !== "NONE";
}
function canCreate(role, moduleKey) {
  return hasFlag(ACCESS_MATRIX[moduleKey]?.[role], "C");
}
function canUpdate(role, moduleKey) {
  return hasFlag(ACCESS_MATRIX[moduleKey]?.[role], "U");
}
function canDelete(role, moduleKey) {
  return hasFlag(ACCESS_MATRIX[moduleKey]?.[role], "D");
}
function canApprove(role, moduleKey) {
  return hasFlag(ACCESS_MATRIX[moduleKey]?.[role], "APPROVE");
}

// netlify/functions-lib/errors.js
var HttpError = class extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
};
var UnauthorizedError = class extends HttpError {
  constructor(message = "You must be signed in to do that.") {
    super(401, message);
  }
};
var ForbiddenError = class extends HttpError {
  constructor(message = "Your role does not have permission to do that.") {
    super(403, message);
  }
};
var ValidationError = class extends HttpError {
  constructor(message) {
    super(422, message);
  }
};
var NotFoundError = class extends HttpError {
  constructor(message = "Record not found.") {
    super(404, message);
  }
};

// netlify/functions-lib/auth.js
async function requireUser() {
  const identityUser = await getUser();
  if (!identityUser) {
    throw new UnauthorizedError();
  }
  const role = identityUser.roles?.[0];
  if (!role) {
    throw new ForbiddenError("Your account has no role assigned. Contact an administrator.");
  }
  const name = identityUser.name || identityUser.userMetadata?.full_name || identityUser.email || "Unknown user";
  return { id: identityUser.id, email: identityUser.email, name, role };
}
var ACTION_CHECKS = {
  read: hasModuleAccess,
  create: canCreate,
  update: canUpdate,
  delete: canDelete,
  approve: canApprove
};
function requireAccess(user, moduleKey, action) {
  const check = ACTION_CHECKS[action];
  if (!check) {
    throw new Error(`Unknown RBAC action "${action}"`);
  }
  if (!check(user.role, moduleKey)) {
    throw new ForbiddenError(
      `Your role (${user.role}) does not have ${action} access to ${moduleKey}.`
    );
  }
}
async function requireUserWithAccess(moduleKey, action) {
  const user = await requireUser();
  requireAccess(user, moduleKey, action);
  return user;
}

// netlify/functions-lib/response.js
function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
}
function errorResponse(err) {
  if (err instanceof HttpError) {
    const body = { error: err.message };
    if (err.payload) body.payload = err.payload;
    return jsonResponse(body, err.status);
  }
  console.error("Unhandled error in function:", err);
  return jsonResponse({ error: "Something went wrong. Please try again." }, 500);
}

// netlify/functions-lib/auditLog.js
async function logAction(db, { user, action, moduleLabel, recordLabel }) {
  try {
    await db.sql`
      INSERT INTO audit_log (user_id, user_name, user_role, action, module_label, record_label)
      VALUES (${user.id}, ${user.name}, ${user.role}, ${action}, ${moduleLabel}, ${recordLabel})
    `;
  } catch (err) {
    console.error("Failed to write audit log entry", err);
  }
}

// netlify/functions-lib/modules/events.js
var MODULE_LABEL = "Events & Calendar";
function toRecord(row, attendees = []) {
  return {
    localId: row.local_id,
    sequenceNumber: row.sequence_number,
    title: row.title,
    type: row.type,
    ministry: row.ministry,
    when: row.when_text,
    status: row.status,
    capacity: row.capacity,
    notes: row.notes,
    attendees,
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}
async function attachAttendees(db, eventRows) {
  if (eventRows.length === 0) return [];
  const ids = eventRows.map((r) => r.id);
  const attendeeRows = await db.sql`
    SELECT id, event_id, name FROM event_attendees WHERE event_id = ANY(${ids}) ORDER BY added_at
  `;
  const byEvent = {};
  for (const a of attendeeRows) {
    ;
    (byEvent[a.event_id] ??= []).push({ id: a.id, name: a.name });
  }
  return eventRows.map((r) => toRecord(r, byEvent[r.id] ?? []));
}
async function getEventByLocalId(db, localId) {
  const rows = await db.sql`SELECT * FROM events WHERE local_id = ${localId}::uuid`;
  if (!rows[0]) throw new NotFoundError();
  const [record] = await attachAttendees(db, rows);
  return record;
}
async function addAttendee(db, { eventLocalId, name, user }) {
  if (!name || !name.trim()) throw new ValidationError("Attendee name is required.");
  const eventRows = await db.sql`SELECT id, title FROM events WHERE local_id = ${eventLocalId}::uuid`;
  if (!eventRows[0]) throw new NotFoundError("Event not found.");
  await db.sql`INSERT INTO event_attendees (event_id, name) VALUES (${eventRows[0].id}, ${name.trim()})`;
  await logAction(db, {
    user,
    action: "updated",
    moduleLabel: MODULE_LABEL,
    recordLabel: `${eventRows[0].title} (attendee added)`
  });
  return getEventByLocalId(db, eventLocalId);
}
async function removeAttendee(db, { eventLocalId, attendeeId, user }) {
  const eventRows = await db.sql`SELECT id, title FROM events WHERE local_id = ${eventLocalId}::uuid`;
  if (!eventRows[0]) throw new NotFoundError("Event not found.");
  const deleted = await db.sql`
    DELETE FROM event_attendees WHERE id = ${attendeeId} AND event_id = ${eventRows[0].id} RETURNING id
  `;
  if (!deleted[0]) throw new NotFoundError("Attendee not found on this event.");
  await logAction(db, {
    user,
    action: "updated",
    moduleLabel: MODULE_LABEL,
    recordLabel: `${eventRows[0].title} (attendee removed)`
  });
  return getEventByLocalId(db, eventLocalId);
}

// netlify/functions/events-attendees.js
var events_attendees_default = async (req) => {
  const db = getDb();
  try {
    const segments = new URL(req.url).pathname.split("/").filter(Boolean);
    const attendeesIndex = segments.indexOf("attendees");
    const eventLocalId = attendeesIndex > 0 ? segments[attendeesIndex - 1] : null;
    if (!eventLocalId) throw new ValidationError("Missing event id in the URL.");
    const user = await requireUserWithAccess("events", "update");
    if (req.method === "POST") {
      const body = await req.json();
      const record = await addAttendee(db, { eventLocalId, name: body.name, user });
      return jsonResponse({ event: record }, 201);
    }
    if (req.method === "DELETE") {
      const attendeeId = segments[attendeesIndex + 1];
      if (!attendeeId) throw new ValidationError("Missing attendee id in the URL.");
      const record = await removeAttendee(db, { eventLocalId, attendeeId, user });
      return jsonResponse({ event: record });
    }
    return jsonResponse({ error: "Method not allowed" }, 405);
  } catch (err) {
    return errorResponse(err);
  }
};
var config = {
  path: ["/api/events/:id/attendees", "/api/events/:id/attendees/:attendeeId"]
};
export {
  config,
  events_attendees_default as default
};
