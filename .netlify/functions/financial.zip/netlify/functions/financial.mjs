
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions-lib/db.js
import { getDatabase } from "@netlify/database";
var cached = null;
function getDb() {
  if (!cached) {
    cached = getDatabase();
  }
  return cached;
}

// netlify/functions-lib/auth.js
import { getUser } from "@netlify/identity";

// src/data/roles.js
var ROLES = {
  SUPER_ADMIN: "SUPER_ADMIN",
  ADMIN: "ADMIN",
  COUNCIL_MEMBER: "COUNCIL_MEMBER",
  TREASURER: "TREASURER",
  CLERGY: "CLERGY",
  MINISTRY_COORDINATOR: "MINISTRY_COORDINATOR",
  STAFF: "STAFF",
  MEMBER: "MEMBER",
  GUEST: "GUEST"
};
var ROLE_LABELS = {
  [ROLES.SUPER_ADMIN]: "Super Admin",
  [ROLES.ADMIN]: "Church Administrator",
  [ROLES.COUNCIL_MEMBER]: "Council Member",
  [ROLES.TREASURER]: "Treasurer",
  [ROLES.CLERGY]: "Clergy / Vicar",
  [ROLES.MINISTRY_COORDINATOR]: "Ministry Coordinator",
  [ROLES.STAFF]: "Staff / Secretary",
  [ROLES.MEMBER]: "Member",
  [ROLES.GUEST]: "Guest"
};
var ACCESS_MATRIX = {
  documents: {
    [ROLES.SUPER_ADMIN]: "CRUD_APPROVE",
    [ROLES.ADMIN]: "CRUD",
    [ROLES.COUNCIL_MEMBER]: "READ_APPROVE",
    [ROLES.TREASURER]: "READ",
    [ROLES.CLERGY]: "CRUD_APPROVE",
    [ROLES.MINISTRY_COORDINATOR]: "CR_SCOPED",
    [ROLES.STAFF]: "CRU",
    [ROLES.MEMBER]: "NONE",
    [ROLES.GUEST]: "NONE"
  },
  ministry: {
    [ROLES.SUPER_ADMIN]: "CRUD",
    [ROLES.ADMIN]: "READ",
    [ROLES.COUNCIL_MEMBER]: "CRU",
    [ROLES.TREASURER]: "READ",
    [ROLES.CLERGY]: "CRUD",
    [ROLES.MINISTRY_COORDINATOR]: "CRUD_SCOPED",
    [ROLES.STAFF]: "READ",
    [ROLES.MEMBER]: "NONE",
    [ROLES.GUEST]: "NONE"
  },
  personnel: {
    [ROLES.SUPER_ADMIN]: "CRUD",
    [ROLES.ADMIN]: "CRUD",
    [ROLES.COUNCIL_MEMBER]: "READ",
    [ROLES.TREASURER]: "READ",
    [ROLES.CLERGY]: "CRU",
    [ROLES.MINISTRY_COORDINATOR]: "READ",
    [ROLES.STAFF]: "READ",
    [ROLES.MEMBER]: "NONE",
    [ROLES.GUEST]: "NONE"
  },
  financial: {
    [ROLES.SUPER_ADMIN]: "CRUD",
    [ROLES.ADMIN]: "CRUD",
    [ROLES.COUNCIL_MEMBER]: "READ",
    [ROLES.TREASURER]: "CRUD",
    [ROLES.CLERGY]: "READ",
    [ROLES.MINISTRY_COORDINATOR]: "READ",
    [ROLES.STAFF]: "READ",
    [ROLES.MEMBER]: "NONE",
    [ROLES.GUEST]: "NONE"
  },
  events: {
    [ROLES.SUPER_ADMIN]: "CRUD",
    [ROLES.ADMIN]: "CRUD",
    [ROLES.COUNCIL_MEMBER]: "CRU",
    [ROLES.TREASURER]: "READ",
    [ROLES.CLERGY]: "CRUD",
    [ROLES.MINISTRY_COORDINATOR]: "CRUD_SCOPED",
    [ROLES.STAFF]: "CR",
    [ROLES.MEMBER]: "READ",
    [ROLES.GUEST]: "READ"
  },
  reports: {
    [ROLES.SUPER_ADMIN]: "CRUD",
    [ROLES.ADMIN]: "CRUD",
    [ROLES.COUNCIL_MEMBER]: "READ",
    [ROLES.TREASURER]: "CRUD",
    [ROLES.CLERGY]: "READ",
    [ROLES.MINISTRY_COORDINATOR]: "READ_SCOPED",
    [ROLES.STAFF]: "READ",
    [ROLES.MEMBER]: "NONE",
    [ROLES.GUEST]: "NONE"
  },
  settings: {
    [ROLES.SUPER_ADMIN]: "CRUD",
    [ROLES.ADMIN]: "CRU",
    [ROLES.COUNCIL_MEMBER]: "NONE",
    [ROLES.TREASURER]: "NONE",
    [ROLES.CLERGY]: "READ",
    [ROLES.MINISTRY_COORDINATOR]: "NONE",
    [ROLES.STAFF]: "NONE",
    [ROLES.MEMBER]: "NONE",
    [ROLES.GUEST]: "NONE"
  }
};
var LEVEL_FLAGS = {
  NONE: [],
  READ: ["R"],
  READ_APPROVE: ["R", "APPROVE"],
  READ_SCOPED: ["R", "SCOPED"],
  CR: ["C", "R"],
  CR_SCOPED: ["C", "R", "SCOPED"],
  CRU: ["C", "R", "U"],
  CRUD: ["C", "R", "U", "D"],
  CRUD_SCOPED: ["C", "R", "U", "D", "SCOPED"],
  CRUD_APPROVE: ["C", "R", "U", "D", "APPROVE"]
};
function hasFlag(level, flag) {
  return (LEVEL_FLAGS[level] ?? []).includes(flag);
}
function hasModuleAccess(role, moduleKey) {
  const level = ACCESS_MATRIX[moduleKey]?.[role];
  return Boolean(level) && level !== "NONE";
}
function canCreate(role, moduleKey) {
  return hasFlag(ACCESS_MATRIX[moduleKey]?.[role], "C");
}
function canUpdate(role, moduleKey) {
  return hasFlag(ACCESS_MATRIX[moduleKey]?.[role], "U");
}
function canDelete(role, moduleKey) {
  return hasFlag(ACCESS_MATRIX[moduleKey]?.[role], "D");
}
function canApprove(role, moduleKey) {
  return hasFlag(ACCESS_MATRIX[moduleKey]?.[role], "APPROVE");
}

// netlify/functions-lib/errors.js
var HttpError = class extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
};
var UnauthorizedError = class extends HttpError {
  constructor(message = "You must be signed in to do that.") {
    super(401, message);
  }
};
var ForbiddenError = class extends HttpError {
  constructor(message = "Your role does not have permission to do that.") {
    super(403, message);
  }
};
var ValidationError = class extends HttpError {
  constructor(message) {
    super(422, message);
  }
};
var ConflictError = class extends HttpError {
  constructor(message, payload) {
    super(409, message);
    this.payload = payload;
  }
};

// netlify/functions-lib/auth.js
async function requireUser() {
  const identityUser = await getUser();
  if (!identityUser) {
    throw new UnauthorizedError();
  }
  const role = identityUser.roles?.[0];
  if (!role) {
    throw new ForbiddenError("Your account has no role assigned. Contact an administrator.");
  }
  const name = identityUser.name || identityUser.userMetadata?.full_name || identityUser.email || "Unknown user";
  return { id: identityUser.id, email: identityUser.email, name, role };
}
var ACTION_CHECKS = {
  read: hasModuleAccess,
  create: canCreate,
  update: canUpdate,
  delete: canDelete,
  approve: canApprove
};
function requireAccess(user, moduleKey, action) {
  const check = ACTION_CHECKS[action];
  if (!check) {
    throw new Error(`Unknown RBAC action "${action}"`);
  }
  if (!check(user.role, moduleKey)) {
    throw new ForbiddenError(
      `Your role (${user.role}) does not have ${action} access to ${moduleKey}.`
    );
  }
}
async function requireUserWithAccess(moduleKey, action) {
  const user = await requireUser();
  requireAccess(user, moduleKey, action);
  return user;
}

// netlify/functions-lib/response.js
function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
}
function errorResponse(err) {
  if (err instanceof HttpError) {
    const body = { error: err.message };
    if (err.payload) body.payload = err.payload;
    return jsonResponse(body, err.status);
  }
  console.error("Unhandled error in function:", err);
  return jsonResponse({ error: "Something went wrong. Please try again." }, 500);
}

// netlify/functions-lib/sequence.js
var SEQUENCES = {
  documents: { seq: "documents_seq", prefix: "DOC" },
  personnel: { seq: "personnel_seq", prefix: "PER" },
  ministries: { seq: "ministries_seq", prefix: "MIN" },
  events: { seq: "events_seq", prefix: "EVT" },
  financial: { seq: "financial_seq", prefix: "FIN" },
  reports: { seq: "reports_seq", prefix: "RPT" }
};
async function nextSequenceNumber(db, moduleKey) {
  const config2 = SEQUENCES[moduleKey];
  if (!config2) {
    throw new Error(`Unknown sequence module "${moduleKey}"`);
  }
  const year = (/* @__PURE__ */ new Date()).getFullYear();
  const { rows } = await db.pool.query(`SELECT nextval('${config2.seq}') AS n`);
  const n = Number(rows[0].n);
  return `${config2.prefix}-${year}-${String(n).padStart(3, "0")}`;
}

// netlify/functions-lib/auditLog.js
async function logAction(db, { user, action, moduleLabel, recordLabel }) {
  try {
    await db.sql`
      INSERT INTO audit_log (user_id, user_name, user_role, action, module_label, record_label)
      VALUES (${user.id}, ${user.name}, ${user.role}, ${action}, ${moduleLabel}, ${recordLabel})
    `;
  } catch (err) {
    console.error("Failed to write audit log entry", err);
  }
}

// netlify/functions-lib/modules/financial.js
var MODULE_KEY = "financial";
var MODULE_LABEL = "Financial";
function validate(input) {
  if (!input.date) return "Date is required.";
  if (!input.type) return "Type is required.";
  if (!input.category) return "Category is required.";
  if (!input.description || !input.description.trim()) return "Description is required.";
  const amount = Number(input.amount);
  if (input.amount == null || Number.isNaN(amount) || amount <= 0) {
    return "Amount must be a positive number.";
  }
  return null;
}
function toRecord(row) {
  return {
    localId: row.local_id,
    sequenceNumber: row.sequence_number,
    date: row.date instanceof Date ? row.date.toISOString().slice(0, 10) : row.date,
    type: row.type,
    category: row.category,
    ministry: row.ministry,
    amount: Number(row.amount),
    description: row.description,
    status: row.status,
    notes: row.notes,
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}
async function listTransactions(db, { search = "", type = "all", status = "all" } = {}) {
  const rows = await db.sql`
    SELECT * FROM financial_transactions
    WHERE (${search} = '' OR description ILIKE ${"%" + search + "%"})
      AND (${type} = 'all' OR type = ${type})
      AND (${status} = 'all' OR status = ${status})
    ORDER BY date DESC, created_at DESC
  `;
  return rows.map(toRecord);
}
async function findDuplicate(db, { date, description, excludeLocalId = null }) {
  const rows = await db.sql`
    SELECT * FROM financial_transactions
    WHERE date = ${date}::date
      AND lower(description) = lower(${description})
      AND (${excludeLocalId}::uuid IS NULL OR local_id != ${excludeLocalId}::uuid)
    LIMIT 1
  `;
  return rows[0] ? toRecord(rows[0]) : null;
}
async function createTransaction(db, { input, user, skipDuplicateCheck = false }) {
  const validationError = validate(input);
  if (validationError) throw new ValidationError(validationError);
  if (!skipDuplicateCheck) {
    const existing = await findDuplicate(db, { date: input.date, description: input.description });
    if (existing)
      throw new ConflictError("A very similar transaction already exists.", { existing });
  }
  const sequenceNumber = await nextSequenceNumber(db, MODULE_KEY);
  const rows = await db.sql`
    INSERT INTO financial_transactions (date, type, category, ministry, amount, description, status, notes, sequence_number, created_by_id, created_by_name)
    VALUES (${input.date}::date, ${input.type}, ${input.category}, ${input.ministry}, ${input.amount}, ${input.description}, ${input.status ?? "Recorded"}, ${input.notes ?? ""}, ${sequenceNumber}, ${user.id}, ${user.name})
    RETURNING *
  `;
  const record = toRecord(rows[0]);
  await logAction(db, {
    user,
    action: "created",
    moduleLabel: MODULE_LABEL,
    recordLabel: record.description
  });
  return record;
}
async function getFinancialTotals(db) {
  const rows = await db.sql`
    SELECT type, COALESCE(SUM(amount), 0) AS total FROM financial_transactions GROUP BY type
  `;
  const income = Number(rows.find((r) => r.type === "Income")?.total ?? 0);
  const expenses = Number(rows.find((r) => r.type === "Expense")?.total ?? 0);
  return { income, expenses, net: income - expenses };
}

// netlify/functions/financial.js
var financial_default = async (req) => {
  const db = getDb();
  try {
    if (req.method === "GET") {
      const user = await requireUserWithAccess("financial", "read");
      const url = new URL(req.url);
      const [rows, totals] = await Promise.all([
        listTransactions(db, {
          search: url.searchParams.get("search") ?? "",
          type: url.searchParams.get("type") ?? "all",
          status: url.searchParams.get("status") ?? "all"
        }),
        getFinancialTotals(db)
      ]);
      return jsonResponse({
        transactions: rows,
        totals,
        canCreate: canCreate(user.role, "financial")
      });
    }
    if (req.method === "POST") {
      const user = await requireUserWithAccess("financial", "create");
      const body = await req.json();
      const record = await createTransaction(db, {
        input: body.input,
        user,
        skipDuplicateCheck: Boolean(body.skipDuplicateCheck)
      });
      return jsonResponse({ transaction: record }, 201);
    }
    return jsonResponse({ error: "Method not allowed" }, 405);
  } catch (err) {
    return errorResponse(err);
  }
};
var config = { path: "/api/financial" };
export {
  config,
  financial_default as default
};
