
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions-lib/db.js
import { getDatabase } from "@netlify/database";
var cached = null;
function getDb() {
  if (!cached) {
    cached = getDatabase();
  }
  return cached;
}

// netlify/functions-lib/auth.js
import { getUser } from "@netlify/identity";

// src/data/roles.js
var ROLES = {
  SUPER_ADMIN: "SUPER_ADMIN",
  ADMIN: "ADMIN",
  COUNCIL_MEMBER: "COUNCIL_MEMBER",
  TREASURER: "TREASURER",
  CLERGY: "CLERGY",
  MINISTRY_COORDINATOR: "MINISTRY_COORDINATOR",
  STAFF: "STAFF",
  MEMBER: "MEMBER",
  GUEST: "GUEST"
};
var ROLE_LABELS = {
  [ROLES.SUPER_ADMIN]: "Super Admin",
  [ROLES.ADMIN]: "Church Administrator",
  [ROLES.COUNCIL_MEMBER]: "Council Member",
  [ROLES.TREASURER]: "Treasurer",
  [ROLES.CLERGY]: "Clergy / Vicar",
  [ROLES.MINISTRY_COORDINATOR]: "Ministry Coordinator",
  [ROLES.STAFF]: "Staff / Secretary",
  [ROLES.MEMBER]: "Member",
  [ROLES.GUEST]: "Guest"
};
var ACCESS_MATRIX = {
  documents: {
    [ROLES.SUPER_ADMIN]: "CRUD_APPROVE",
    [ROLES.ADMIN]: "CRUD",
    [ROLES.COUNCIL_MEMBER]: "READ_APPROVE",
    [ROLES.TREASURER]: "READ",
    [ROLES.CLERGY]: "CRUD_APPROVE",
    [ROLES.MINISTRY_COORDINATOR]: "CR_SCOPED",
    [ROLES.STAFF]: "CRU",
    [ROLES.MEMBER]: "NONE",
    [ROLES.GUEST]: "NONE"
  },
  ministry: {
    [ROLES.SUPER_ADMIN]: "CRUD",
    [ROLES.ADMIN]: "READ",
    [ROLES.COUNCIL_MEMBER]: "CRU",
    [ROLES.TREASURER]: "READ",
    [ROLES.CLERGY]: "CRUD",
    [ROLES.MINISTRY_COORDINATOR]: "CRUD_SCOPED",
    [ROLES.STAFF]: "READ",
    [ROLES.MEMBER]: "NONE",
    [ROLES.GUEST]: "NONE"
  },
  personnel: {
    [ROLES.SUPER_ADMIN]: "CRUD",
    [ROLES.ADMIN]: "CRUD",
    [ROLES.COUNCIL_MEMBER]: "READ",
    [ROLES.TREASURER]: "READ",
    [ROLES.CLERGY]: "CRU",
    [ROLES.MINISTRY_COORDINATOR]: "READ",
    [ROLES.STAFF]: "READ",
    [ROLES.MEMBER]: "NONE",
    [ROLES.GUEST]: "NONE"
  },
  financial: {
    [ROLES.SUPER_ADMIN]: "CRUD",
    [ROLES.ADMIN]: "CRUD",
    [ROLES.COUNCIL_MEMBER]: "READ",
    [ROLES.TREASURER]: "CRUD",
    [ROLES.CLERGY]: "READ",
    [ROLES.MINISTRY_COORDINATOR]: "READ",
    [ROLES.STAFF]: "READ",
    [ROLES.MEMBER]: "NONE",
    [ROLES.GUEST]: "NONE"
  },
  events: {
    [ROLES.SUPER_ADMIN]: "CRUD",
    [ROLES.ADMIN]: "CRUD",
    [ROLES.COUNCIL_MEMBER]: "CRU",
    [ROLES.TREASURER]: "READ",
    [ROLES.CLERGY]: "CRUD",
    [ROLES.MINISTRY_COORDINATOR]: "CRUD_SCOPED",
    [ROLES.STAFF]: "CR",
    [ROLES.MEMBER]: "READ",
    [ROLES.GUEST]: "READ"
  },
  reports: {
    [ROLES.SUPER_ADMIN]: "CRUD",
    [ROLES.ADMIN]: "CRUD",
    [ROLES.COUNCIL_MEMBER]: "READ",
    [ROLES.TREASURER]: "CRUD",
    [ROLES.CLERGY]: "READ",
    [ROLES.MINISTRY_COORDINATOR]: "READ_SCOPED",
    [ROLES.STAFF]: "READ",
    [ROLES.MEMBER]: "NONE",
    [ROLES.GUEST]: "NONE"
  },
  settings: {
    [ROLES.SUPER_ADMIN]: "CRUD",
    [ROLES.ADMIN]: "CRU",
    [ROLES.COUNCIL_MEMBER]: "NONE",
    [ROLES.TREASURER]: "NONE",
    [ROLES.CLERGY]: "READ",
    [ROLES.MINISTRY_COORDINATOR]: "NONE",
    [ROLES.STAFF]: "NONE",
    [ROLES.MEMBER]: "NONE",
    [ROLES.GUEST]: "NONE"
  }
};
var LEVEL_FLAGS = {
  NONE: [],
  READ: ["R"],
  READ_APPROVE: ["R", "APPROVE"],
  READ_SCOPED: ["R", "SCOPED"],
  CR: ["C", "R"],
  CR_SCOPED: ["C", "R", "SCOPED"],
  CRU: ["C", "R", "U"],
  CRUD: ["C", "R", "U", "D"],
  CRUD_SCOPED: ["C", "R", "U", "D", "SCOPED"],
  CRUD_APPROVE: ["C", "R", "U", "D", "APPROVE"]
};
function hasFlag(level, flag) {
  return (LEVEL_FLAGS[level] ?? []).includes(flag);
}
function hasModuleAccess(role, moduleKey) {
  const level = ACCESS_MATRIX[moduleKey]?.[role];
  return Boolean(level) && level !== "NONE";
}
function canCreate(role, moduleKey) {
  return hasFlag(ACCESS_MATRIX[moduleKey]?.[role], "C");
}
function canUpdate(role, moduleKey) {
  return hasFlag(ACCESS_MATRIX[moduleKey]?.[role], "U");
}
function canDelete(role, moduleKey) {
  return hasFlag(ACCESS_MATRIX[moduleKey]?.[role], "D");
}
function canApprove(role, moduleKey) {
  return hasFlag(ACCESS_MATRIX[moduleKey]?.[role], "APPROVE");
}

// netlify/functions-lib/errors.js
var HttpError = class extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
};
var UnauthorizedError = class extends HttpError {
  constructor(message = "You must be signed in to do that.") {
    super(401, message);
  }
};
var ForbiddenError = class extends HttpError {
  constructor(message = "Your role does not have permission to do that.") {
    super(403, message);
  }
};
var ValidationError = class extends HttpError {
  constructor(message) {
    super(422, message);
  }
};
var ConflictError = class extends HttpError {
  constructor(message, payload) {
    super(409, message);
    this.payload = payload;
  }
};

// netlify/functions-lib/auth.js
async function requireUser() {
  const identityUser = await getUser();
  if (!identityUser) {
    throw new UnauthorizedError();
  }
  const role = identityUser.roles?.[0];
  if (!role) {
    throw new ForbiddenError("Your account has no role assigned. Contact an administrator.");
  }
  const name = identityUser.name || identityUser.userMetadata?.full_name || identityUser.email || "Unknown user";
  return { id: identityUser.id, email: identityUser.email, name, role };
}
var ACTION_CHECKS = {
  read: hasModuleAccess,
  create: canCreate,
  update: canUpdate,
  delete: canDelete,
  approve: canApprove
};
function requireAccess(user, moduleKey, action) {
  const check = ACTION_CHECKS[action];
  if (!check) {
    throw new Error(`Unknown RBAC action "${action}"`);
  }
  if (!check(user.role, moduleKey)) {
    throw new ForbiddenError(
      `Your role (${user.role}) does not have ${action} access to ${moduleKey}.`
    );
  }
}
async function requireUserWithAccess(moduleKey, action) {
  const user = await requireUser();
  requireAccess(user, moduleKey, action);
  return user;
}

// netlify/functions-lib/response.js
function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
}
function errorResponse(err) {
  if (err instanceof HttpError) {
    const body = { error: err.message };
    if (err.payload) body.payload = err.payload;
    return jsonResponse(body, err.status);
  }
  console.error("Unhandled error in function:", err);
  return jsonResponse({ error: "Something went wrong. Please try again." }, 500);
}

// netlify/functions-lib/sequence.js
var SEQUENCES = {
  documents: { seq: "documents_seq", prefix: "DOC" },
  personnel: { seq: "personnel_seq", prefix: "PER" },
  ministries: { seq: "ministries_seq", prefix: "MIN" },
  events: { seq: "events_seq", prefix: "EVT" },
  financial: { seq: "financial_seq", prefix: "FIN" },
  reports: { seq: "reports_seq", prefix: "RPT" }
};
async function nextSequenceNumber(db, moduleKey) {
  const config2 = SEQUENCES[moduleKey];
  if (!config2) {
    throw new Error(`Unknown sequence module "${moduleKey}"`);
  }
  const year = (/* @__PURE__ */ new Date()).getFullYear();
  const { rows } = await db.pool.query(`SELECT nextval('${config2.seq}') AS n`);
  const n = Number(rows[0].n);
  return `${config2.prefix}-${year}-${String(n).padStart(3, "0")}`;
}

// netlify/functions-lib/auditLog.js
async function logAction(db, { user, action, moduleLabel, recordLabel }) {
  try {
    await db.sql`
      INSERT INTO audit_log (user_id, user_name, user_role, action, module_label, record_label)
      VALUES (${user.id}, ${user.name}, ${user.role}, ${action}, ${moduleLabel}, ${recordLabel})
    `;
  } catch (err) {
    console.error("Failed to write audit log entry", err);
  }
}

// netlify/functions-lib/modules/personnel.js
var MODULE_KEY = "personnel";
var MODULE_LABEL = "Personnel";
function validate(input) {
  if (!input.name || !input.name.trim()) return "Name is required.";
  if (!input.title || !input.title.trim()) return "Role/title is required.";
  return null;
}
function toRecord(row) {
  return {
    localId: row.local_id,
    sequenceNumber: row.sequence_number,
    name: row.name,
    title: row.title,
    category: row.category,
    ministry: row.ministry,
    status: row.status,
    email: row.email,
    phone: row.phone,
    notes: row.notes,
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}
async function listPersonnel(db, { search = "", category = "all", status = "all" } = {}) {
  const rows = await db.sql`
    SELECT * FROM personnel
    WHERE (${search} = '' OR name ILIKE ${"%" + search + "%"})
      AND (${category} = 'all' OR category = ${category})
      AND (${status} = 'all' OR status = ${status})
    ORDER BY created_at DESC
  `;
  return rows.map(toRecord);
}
async function findDuplicate(db, { name, excludeLocalId = null }) {
  const rows = await db.sql`
    SELECT * FROM personnel
    WHERE lower(name) = lower(${name})
      AND (${excludeLocalId}::uuid IS NULL OR local_id != ${excludeLocalId}::uuid)
    LIMIT 1
  `;
  return rows[0] ? toRecord(rows[0]) : null;
}
async function createPersonnel(db, { input, user, skipDuplicateCheck = false }) {
  const validationError = validate(input);
  if (validationError) throw new ValidationError(validationError);
  if (!skipDuplicateCheck) {
    const existing = await findDuplicate(db, { name: input.name });
    if (existing) {
      throw new ConflictError("A very similar person already exists.", { existing });
    }
  }
  const sequenceNumber = await nextSequenceNumber(db, MODULE_KEY);
  const rows = await db.sql`
    INSERT INTO personnel (name, title, category, ministry, status, email, phone, notes, sequence_number, created_by_id, created_by_name)
    VALUES (${input.name}, ${input.title}, ${input.category}, ${input.ministry ?? null}, ${input.status ?? "Active"}, ${input.email ?? ""}, ${input.phone ?? ""}, ${input.notes ?? ""}, ${sequenceNumber}, ${user.id}, ${user.name})
    RETURNING *
  `;
  const record = toRecord(rows[0]);
  await logAction(db, {
    user,
    action: "created",
    moduleLabel: MODULE_LABEL,
    recordLabel: record.name
  });
  return record;
}

// netlify/functions/personnel.js
var personnel_default = async (req) => {
  const db = getDb();
  try {
    if (req.method === "GET") {
      const user = await requireUserWithAccess("personnel", "read");
      const url = new URL(req.url);
      const rows = await listPersonnel(db, {
        search: url.searchParams.get("search") ?? "",
        category: url.searchParams.get("category") ?? "all",
        status: url.searchParams.get("status") ?? "all"
      });
      return jsonResponse({ personnel: rows, canCreate: canCreate(user.role, "personnel") });
    }
    if (req.method === "POST") {
      const user = await requireUserWithAccess("personnel", "create");
      const body = await req.json();
      const record = await createPersonnel(db, {
        input: body.input,
        user,
        skipDuplicateCheck: Boolean(body.skipDuplicateCheck)
      });
      return jsonResponse({ person: record }, 201);
    }
    return jsonResponse({ error: "Method not allowed" }, 405);
  } catch (err) {
    return errorResponse(err);
  }
};
var config = { path: "/api/personnel" };
export {
  config,
  personnel_default as default
};
