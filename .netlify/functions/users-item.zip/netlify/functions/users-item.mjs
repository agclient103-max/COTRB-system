
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions-lib/auth.js
import { getUser } from "@netlify/identity";

// src/data/roles.js
var ROLES = {
  SUPER_ADMIN: "SUPER_ADMIN",
  ADMIN: "ADMIN",
  COUNCIL_MEMBER: "COUNCIL_MEMBER",
  TREASURER: "TREASURER",
  CLERGY: "CLERGY",
  MINISTRY_COORDINATOR: "MINISTRY_COORDINATOR",
  STAFF: "STAFF",
  MEMBER: "MEMBER",
  GUEST: "GUEST"
};
var ROLE_LABELS = {
  [ROLES.SUPER_ADMIN]: "Super Admin",
  [ROLES.ADMIN]: "Church Administrator",
  [ROLES.COUNCIL_MEMBER]: "Council Member",
  [ROLES.TREASURER]: "Treasurer",
  [ROLES.CLERGY]: "Clergy / Vicar",
  [ROLES.MINISTRY_COORDINATOR]: "Ministry Coordinator",
  [ROLES.STAFF]: "Staff / Secretary",
  [ROLES.MEMBER]: "Member",
  [ROLES.GUEST]: "Guest"
};
var ACCESS_MATRIX = {
  documents: {
    [ROLES.SUPER_ADMIN]: "CRUD_APPROVE",
    [ROLES.ADMIN]: "CRUD",
    [ROLES.COUNCIL_MEMBER]: "READ_APPROVE",
    [ROLES.TREASURER]: "READ",
    [ROLES.CLERGY]: "CRUD_APPROVE",
    [ROLES.MINISTRY_COORDINATOR]: "CR_SCOPED",
    [ROLES.STAFF]: "CRU",
    [ROLES.MEMBER]: "NONE",
    [ROLES.GUEST]: "NONE"
  },
  ministry: {
    [ROLES.SUPER_ADMIN]: "CRUD",
    [ROLES.ADMIN]: "READ",
    [ROLES.COUNCIL_MEMBER]: "CRU",
    [ROLES.TREASURER]: "READ",
    [ROLES.CLERGY]: "CRUD",
    [ROLES.MINISTRY_COORDINATOR]: "CRUD_SCOPED",
    [ROLES.STAFF]: "READ",
    [ROLES.MEMBER]: "NONE",
    [ROLES.GUEST]: "NONE"
  },
  personnel: {
    [ROLES.SUPER_ADMIN]: "CRUD",
    [ROLES.ADMIN]: "CRUD",
    [ROLES.COUNCIL_MEMBER]: "READ",
    [ROLES.TREASURER]: "READ",
    [ROLES.CLERGY]: "CRU",
    [ROLES.MINISTRY_COORDINATOR]: "READ",
    [ROLES.STAFF]: "READ",
    [ROLES.MEMBER]: "NONE",
    [ROLES.GUEST]: "NONE"
  },
  financial: {
    [ROLES.SUPER_ADMIN]: "CRUD",
    [ROLES.ADMIN]: "CRUD",
    [ROLES.COUNCIL_MEMBER]: "READ",
    [ROLES.TREASURER]: "CRUD",
    [ROLES.CLERGY]: "READ",
    [ROLES.MINISTRY_COORDINATOR]: "READ",
    [ROLES.STAFF]: "READ",
    [ROLES.MEMBER]: "NONE",
    [ROLES.GUEST]: "NONE"
  },
  events: {
    [ROLES.SUPER_ADMIN]: "CRUD",
    [ROLES.ADMIN]: "CRUD",
    [ROLES.COUNCIL_MEMBER]: "CRU",
    [ROLES.TREASURER]: "READ",
    [ROLES.CLERGY]: "CRUD",
    [ROLES.MINISTRY_COORDINATOR]: "CRUD_SCOPED",
    [ROLES.STAFF]: "CR",
    [ROLES.MEMBER]: "READ",
    [ROLES.GUEST]: "READ"
  },
  reports: {
    [ROLES.SUPER_ADMIN]: "CRUD",
    [ROLES.ADMIN]: "CRUD",
    [ROLES.COUNCIL_MEMBER]: "READ",
    [ROLES.TREASURER]: "CRUD",
    [ROLES.CLERGY]: "READ",
    [ROLES.MINISTRY_COORDINATOR]: "READ_SCOPED",
    [ROLES.STAFF]: "READ",
    [ROLES.MEMBER]: "NONE",
    [ROLES.GUEST]: "NONE"
  },
  settings: {
    [ROLES.SUPER_ADMIN]: "CRUD",
    [ROLES.ADMIN]: "CRU",
    [ROLES.COUNCIL_MEMBER]: "NONE",
    [ROLES.TREASURER]: "NONE",
    [ROLES.CLERGY]: "READ",
    [ROLES.MINISTRY_COORDINATOR]: "NONE",
    [ROLES.STAFF]: "NONE",
    [ROLES.MEMBER]: "NONE",
    [ROLES.GUEST]: "NONE"
  }
};
var LEVEL_FLAGS = {
  NONE: [],
  READ: ["R"],
  READ_APPROVE: ["R", "APPROVE"],
  READ_SCOPED: ["R", "SCOPED"],
  CR: ["C", "R"],
  CR_SCOPED: ["C", "R", "SCOPED"],
  CRU: ["C", "R", "U"],
  CRUD: ["C", "R", "U", "D"],
  CRUD_SCOPED: ["C", "R", "U", "D", "SCOPED"],
  CRUD_APPROVE: ["C", "R", "U", "D", "APPROVE"]
};
function hasFlag(level, flag) {
  return (LEVEL_FLAGS[level] ?? []).includes(flag);
}
function hasModuleAccess(role, moduleKey) {
  const level = ACCESS_MATRIX[moduleKey]?.[role];
  return Boolean(level) && level !== "NONE";
}
function canCreate(role, moduleKey) {
  return hasFlag(ACCESS_MATRIX[moduleKey]?.[role], "C");
}
function canUpdate(role, moduleKey) {
  return hasFlag(ACCESS_MATRIX[moduleKey]?.[role], "U");
}
function canDelete(role, moduleKey) {
  return hasFlag(ACCESS_MATRIX[moduleKey]?.[role], "D");
}
function canApprove(role, moduleKey) {
  return hasFlag(ACCESS_MATRIX[moduleKey]?.[role], "APPROVE");
}

// netlify/functions-lib/errors.js
var HttpError = class extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
};
var UnauthorizedError = class extends HttpError {
  constructor(message = "You must be signed in to do that.") {
    super(401, message);
  }
};
var ForbiddenError = class extends HttpError {
  constructor(message = "Your role does not have permission to do that.") {
    super(403, message);
  }
};
var ValidationError = class extends HttpError {
  constructor(message) {
    super(422, message);
  }
};

// netlify/functions-lib/auth.js
async function requireUser() {
  const identityUser = await getUser();
  if (!identityUser) {
    throw new UnauthorizedError();
  }
  const role = identityUser.roles?.[0];
  if (!role) {
    throw new ForbiddenError("Your account has no role assigned. Contact an administrator.");
  }
  const name = identityUser.name || identityUser.userMetadata?.full_name || identityUser.email || "Unknown user";
  return { id: identityUser.id, email: identityUser.email, name, role };
}
var ACTION_CHECKS = {
  read: hasModuleAccess,
  create: canCreate,
  update: canUpdate,
  delete: canDelete,
  approve: canApprove
};
function requireAccess(user, moduleKey, action) {
  const check = ACTION_CHECKS[action];
  if (!check) {
    throw new Error(`Unknown RBAC action "${action}"`);
  }
  if (!check(user.role, moduleKey)) {
    throw new ForbiddenError(
      `Your role (${user.role}) does not have ${action} access to ${moduleKey}.`
    );
  }
}
async function requireUserWithAccess(moduleKey, action) {
  const user = await requireUser();
  requireAccess(user, moduleKey, action);
  return user;
}

// netlify/functions-lib/response.js
function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
}
function errorResponse(err) {
  if (err instanceof HttpError) {
    const body = { error: err.message };
    if (err.payload) body.payload = err.payload;
    return jsonResponse(body, err.status);
  }
  console.error("Unhandled error in function:", err);
  return jsonResponse({ error: "Something went wrong. Please try again." }, 500);
}

// netlify/functions-lib/modules/users.js
import { admin } from "@netlify/identity";
var VALID_ROLES = Object.values(ROLES);
function toSummary(identityUser) {
  return {
    id: identityUser.id,
    email: identityUser.email,
    name: identityUser.name ?? identityUser.userMetadata?.full_name ?? identityUser.email,
    role: identityUser.roles?.[0] ?? null,
    createdAt: identityUser.createdAt,
    lastSignInAt: identityUser.lastSignInAt
  };
}
async function updateUserRole(userId, role) {
  if (!VALID_ROLES.includes(role)) throw new ValidationError("A valid role is required.");
  const updated = await admin.updateUser(userId, { app_metadata: { roles: [role] } });
  return toSummary(updated);
}
async function deleteUser(userId) {
  await admin.deleteUser(userId);
}

// netlify/functions-lib/auditLog.js
async function logAction(db, { user, action, moduleLabel, recordLabel }) {
  try {
    await db.sql`
      INSERT INTO audit_log (user_id, user_name, user_role, action, module_label, record_label)
      VALUES (${user.id}, ${user.name}, ${user.role}, ${action}, ${moduleLabel}, ${recordLabel})
    `;
  } catch (err) {
    console.error("Failed to write audit log entry", err);
  }
}

// netlify/functions-lib/db.js
import { getDatabase } from "@netlify/database";
var cached = null;
function getDb() {
  if (!cached) {
    cached = getDatabase();
  }
  return cached;
}

// netlify/functions/users-item.js
var users_item_default = async (req) => {
  try {
    const segments = new URL(req.url).pathname.split("/").filter(Boolean);
    const userId = segments[segments.length - 1];
    if (!userId || userId === "users") throw new ValidationError("Missing user id in the URL.");
    if (req.method === "PUT") {
      const actingUser = await requireUserWithAccess("settings", "update");
      const body = await req.json();
      const updated = await updateUserRole(userId, body.role);
      await logAction(getDb(), {
        user: actingUser,
        action: "updated",
        moduleLabel: "Settings",
        recordLabel: `User role: ${updated.email} \u2192 ${body.role}`
      });
      return jsonResponse({ user: updated });
    }
    if (req.method === "DELETE") {
      const actingUser = await requireUserWithAccess("settings", "delete");
      await deleteUser(userId);
      await logAction(getDb(), {
        user: actingUser,
        action: "deleted",
        moduleLabel: "Settings",
        recordLabel: `User account: ${userId}`
      });
      return jsonResponse({ success: true });
    }
    return jsonResponse({ error: "Method not allowed" }, 405);
  } catch (err) {
    return errorResponse(err);
  }
};
var config = { path: "/api/users/:id" };
export {
  config,
  users_item_default as default
};
