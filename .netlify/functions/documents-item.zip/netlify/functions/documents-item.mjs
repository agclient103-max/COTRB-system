
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions-lib/db.js
import { getDatabase } from "@netlify/database";
var cached = null;
function getDb() {
  if (!cached) {
    cached = getDatabase();
  }
  return cached;
}

// netlify/functions-lib/auth.js
import { getUser } from "@netlify/identity";

// src/data/roles.js
var ROLES = {
  SUPER_ADMIN: "SUPER_ADMIN",
  ADMIN: "ADMIN",
  COUNCIL_MEMBER: "COUNCIL_MEMBER",
  TREASURER: "TREASURER",
  CLERGY: "CLERGY",
  MINISTRY_COORDINATOR: "MINISTRY_COORDINATOR",
  STAFF: "STAFF",
  MEMBER: "MEMBER",
  GUEST: "GUEST"
};
var ROLE_LABELS = {
  [ROLES.SUPER_ADMIN]: "Super Admin",
  [ROLES.ADMIN]: "Church Administrator",
  [ROLES.COUNCIL_MEMBER]: "Council Member",
  [ROLES.TREASURER]: "Treasurer",
  [ROLES.CLERGY]: "Clergy / Vicar",
  [ROLES.MINISTRY_COORDINATOR]: "Ministry Coordinator",
  [ROLES.STAFF]: "Staff / Secretary",
  [ROLES.MEMBER]: "Member",
  [ROLES.GUEST]: "Guest"
};
var ACCESS_MATRIX = {
  documents: {
    [ROLES.SUPER_ADMIN]: "CRUD_APPROVE",
    [ROLES.ADMIN]: "CRUD",
    [ROLES.COUNCIL_MEMBER]: "READ_APPROVE",
    [ROLES.TREASURER]: "READ",
    [ROLES.CLERGY]: "CRUD_APPROVE",
    [ROLES.MINISTRY_COORDINATOR]: "CR_SCOPED",
    [ROLES.STAFF]: "CRU",
    [ROLES.MEMBER]: "NONE",
    [ROLES.GUEST]: "NONE"
  },
  ministry: {
    [ROLES.SUPER_ADMIN]: "CRUD",
    [ROLES.ADMIN]: "READ",
    [ROLES.COUNCIL_MEMBER]: "CRU",
    [ROLES.TREASURER]: "READ",
    [ROLES.CLERGY]: "CRUD",
    [ROLES.MINISTRY_COORDINATOR]: "CRUD_SCOPED",
    [ROLES.STAFF]: "READ",
    [ROLES.MEMBER]: "NONE",
    [ROLES.GUEST]: "NONE"
  },
  personnel: {
    [ROLES.SUPER_ADMIN]: "CRUD",
    [ROLES.ADMIN]: "CRUD",
    [ROLES.COUNCIL_MEMBER]: "READ",
    [ROLES.TREASURER]: "READ",
    [ROLES.CLERGY]: "CRU",
    [ROLES.MINISTRY_COORDINATOR]: "READ",
    [ROLES.STAFF]: "READ",
    [ROLES.MEMBER]: "NONE",
    [ROLES.GUEST]: "NONE"
  },
  financial: {
    [ROLES.SUPER_ADMIN]: "CRUD",
    [ROLES.ADMIN]: "CRUD",
    [ROLES.COUNCIL_MEMBER]: "READ",
    [ROLES.TREASURER]: "CRUD",
    [ROLES.CLERGY]: "READ",
    [ROLES.MINISTRY_COORDINATOR]: "READ",
    [ROLES.STAFF]: "READ",
    [ROLES.MEMBER]: "NONE",
    [ROLES.GUEST]: "NONE"
  },
  events: {
    [ROLES.SUPER_ADMIN]: "CRUD",
    [ROLES.ADMIN]: "CRUD",
    [ROLES.COUNCIL_MEMBER]: "CRU",
    [ROLES.TREASURER]: "READ",
    [ROLES.CLERGY]: "CRUD",
    [ROLES.MINISTRY_COORDINATOR]: "CRUD_SCOPED",
    [ROLES.STAFF]: "CR",
    [ROLES.MEMBER]: "READ",
    [ROLES.GUEST]: "READ"
  },
  reports: {
    [ROLES.SUPER_ADMIN]: "CRUD",
    [ROLES.ADMIN]: "CRUD",
    [ROLES.COUNCIL_MEMBER]: "READ",
    [ROLES.TREASURER]: "CRUD",
    [ROLES.CLERGY]: "READ",
    [ROLES.MINISTRY_COORDINATOR]: "READ_SCOPED",
    [ROLES.STAFF]: "READ",
    [ROLES.MEMBER]: "NONE",
    [ROLES.GUEST]: "NONE"
  },
  settings: {
    [ROLES.SUPER_ADMIN]: "CRUD",
    [ROLES.ADMIN]: "CRU",
    [ROLES.COUNCIL_MEMBER]: "NONE",
    [ROLES.TREASURER]: "NONE",
    [ROLES.CLERGY]: "READ",
    [ROLES.MINISTRY_COORDINATOR]: "NONE",
    [ROLES.STAFF]: "NONE",
    [ROLES.MEMBER]: "NONE",
    [ROLES.GUEST]: "NONE"
  }
};
var LEVEL_FLAGS = {
  NONE: [],
  READ: ["R"],
  READ_APPROVE: ["R", "APPROVE"],
  READ_SCOPED: ["R", "SCOPED"],
  CR: ["C", "R"],
  CR_SCOPED: ["C", "R", "SCOPED"],
  CRU: ["C", "R", "U"],
  CRUD: ["C", "R", "U", "D"],
  CRUD_SCOPED: ["C", "R", "U", "D", "SCOPED"],
  CRUD_APPROVE: ["C", "R", "U", "D", "APPROVE"]
};
function hasFlag(level, flag) {
  return (LEVEL_FLAGS[level] ?? []).includes(flag);
}
function hasModuleAccess(role, moduleKey) {
  const level = ACCESS_MATRIX[moduleKey]?.[role];
  return Boolean(level) && level !== "NONE";
}
function canCreate(role, moduleKey) {
  return hasFlag(ACCESS_MATRIX[moduleKey]?.[role], "C");
}
function canUpdate(role, moduleKey) {
  return hasFlag(ACCESS_MATRIX[moduleKey]?.[role], "U");
}
function canDelete(role, moduleKey) {
  return hasFlag(ACCESS_MATRIX[moduleKey]?.[role], "D");
}
function canApprove(role, moduleKey) {
  return hasFlag(ACCESS_MATRIX[moduleKey]?.[role], "APPROVE");
}

// netlify/functions-lib/errors.js
var HttpError = class extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
};
var UnauthorizedError = class extends HttpError {
  constructor(message = "You must be signed in to do that.") {
    super(401, message);
  }
};
var ForbiddenError = class extends HttpError {
  constructor(message = "Your role does not have permission to do that.") {
    super(403, message);
  }
};
var ValidationError = class extends HttpError {
  constructor(message) {
    super(422, message);
  }
};
var NotFoundError = class extends HttpError {
  constructor(message = "Record not found.") {
    super(404, message);
  }
};
var ConflictError = class extends HttpError {
  constructor(message, payload) {
    super(409, message);
    this.payload = payload;
  }
};

// netlify/functions-lib/auth.js
async function requireUser() {
  const identityUser = await getUser();
  if (!identityUser) {
    throw new UnauthorizedError();
  }
  const role = identityUser.roles?.[0];
  if (!role) {
    throw new ForbiddenError("Your account has no role assigned. Contact an administrator.");
  }
  const name = identityUser.name || identityUser.userMetadata?.full_name || identityUser.email || "Unknown user";
  return { id: identityUser.id, email: identityUser.email, name, role };
}
var ACTION_CHECKS = {
  read: hasModuleAccess,
  create: canCreate,
  update: canUpdate,
  delete: canDelete,
  approve: canApprove
};
function requireAccess(user, moduleKey, action) {
  const check = ACTION_CHECKS[action];
  if (!check) {
    throw new Error(`Unknown RBAC action "${action}"`);
  }
  if (!check(user.role, moduleKey)) {
    throw new ForbiddenError(
      `Your role (${user.role}) does not have ${action} access to ${moduleKey}.`
    );
  }
}
async function requireUserWithAccess(moduleKey, action) {
  const user = await requireUser();
  requireAccess(user, moduleKey, action);
  return user;
}

// netlify/functions-lib/response.js
function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
}
function errorResponse(err) {
  if (err instanceof HttpError) {
    const body = { error: err.message };
    if (err.payload) body.payload = err.payload;
    return jsonResponse(body, err.status);
  }
  console.error("Unhandled error in function:", err);
  return jsonResponse({ error: "Something went wrong. Please try again." }, 500);
}

// netlify/functions-lib/auditLog.js
async function logAction(db, { user, action, moduleLabel, recordLabel }) {
  try {
    await db.sql`
      INSERT INTO audit_log (user_id, user_name, user_role, action, module_label, record_label)
      VALUES (${user.id}, ${user.name}, ${user.role}, ${action}, ${moduleLabel}, ${recordLabel})
    `;
  } catch (err) {
    console.error("Failed to write audit log entry", err);
  }
}

// netlify/functions-lib/modules/documents.js
var MODULE_LABEL = "Documents";
function validate(input) {
  if (!input.title || !input.title.trim()) return "Title is required.";
  if (!input.category) return "Category is required.";
  if (!input.ministry) return "Ministry is required.";
  return null;
}
function toRecord(row) {
  return {
    localId: row.local_id,
    sequenceNumber: row.sequence_number,
    title: row.title,
    category: row.category,
    ministry: row.ministry,
    status: row.status,
    fileName: row.file_name,
    notes: row.notes,
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}
async function findDuplicate(db, { title, ministry, excludeLocalId = null }) {
  const rows = await db.sql`
    SELECT * FROM documents
    WHERE lower(title) = lower(${title})
      AND ministry = ${ministry}
      AND (${excludeLocalId}::uuid IS NULL OR local_id != ${excludeLocalId}::uuid)
    LIMIT 1
  `;
  return rows[0] ? toRecord(rows[0]) : null;
}
async function updateDocument(db, { localId, input, user, skipDuplicateCheck = false }) {
  const validationError = validate(input);
  if (validationError) throw new ValidationError(validationError);
  const existingRows = await db.sql`SELECT * FROM documents WHERE local_id = ${localId}::uuid`;
  if (!existingRows[0]) throw new NotFoundError();
  if (!skipDuplicateCheck) {
    const duplicate = await findDuplicate(db, {
      title: input.title,
      ministry: input.ministry,
      excludeLocalId: localId
    });
    if (duplicate) {
      throw new ConflictError("A very similar document already exists.", { existing: duplicate });
    }
  }
  const rows = await db.sql`
    UPDATE documents
    SET title = ${input.title}, category = ${input.category}, ministry = ${input.ministry},
        status = ${input.status}, notes = ${input.notes ?? ""}
    WHERE local_id = ${localId}::uuid
    RETURNING *
  `;
  const record = toRecord(rows[0]);
  await logAction(db, {
    user,
    action: "updated",
    moduleLabel: MODULE_LABEL,
    recordLabel: record.title
  });
  return record;
}
async function deleteDocument(db, { localId, user }) {
  const rows = await db.sql`DELETE FROM documents WHERE local_id = ${localId}::uuid RETURNING title`;
  if (!rows[0]) throw new NotFoundError();
  await logAction(db, {
    user,
    action: "deleted",
    moduleLabel: MODULE_LABEL,
    recordLabel: rows[0].title
  });
}

// netlify/functions/documents-item.js
var documents_item_default = async (req) => {
  const db = getDb();
  try {
    const segments = new URL(req.url).pathname.split("/").filter(Boolean);
    const localId = segments[segments.length - 1];
    if (!localId || localId === "documents") {
      throw new ValidationError("Missing document id in the URL.");
    }
    if (req.method === "PUT") {
      const user = await requireUserWithAccess("documents", "update");
      const body = await req.json();
      const record = await updateDocument(db, {
        localId,
        input: body.input,
        user,
        skipDuplicateCheck: Boolean(body.skipDuplicateCheck)
      });
      return jsonResponse({ document: record });
    }
    if (req.method === "DELETE") {
      const user = await requireUserWithAccess("documents", "delete");
      await deleteDocument(db, { localId, user });
      return jsonResponse({ success: true });
    }
    return jsonResponse({ error: "Method not allowed" }, 405);
  } catch (err) {
    return errorResponse(err);
  }
};
var config = { path: "/api/documents/:id" };
export {
  config,
  documents_item_default as default
};
