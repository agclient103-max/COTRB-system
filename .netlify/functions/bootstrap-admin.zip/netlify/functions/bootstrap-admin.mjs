
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/bootstrap-admin.js
import { admin } from "@netlify/identity";

// netlify/functions-lib/errors.js
var HttpError = class extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
};
var ForbiddenError = class extends HttpError {
  constructor(message = "Your role does not have permission to do that.") {
    super(403, message);
  }
};
var ValidationError = class extends HttpError {
  constructor(message) {
    super(422, message);
  }
};
var NotFoundError = class extends HttpError {
  constructor(message = "Record not found.") {
    super(404, message);
  }
};

// netlify/functions-lib/response.js
function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
}
function errorResponse(err) {
  if (err instanceof HttpError) {
    const body = { error: err.message };
    if (err.payload) body.payload = err.payload;
    return jsonResponse(body, err.status);
  }
  console.error("Unhandled error in function:", err);
  return jsonResponse({ error: "Something went wrong. Please try again." }, 500);
}

// src/data/roles.js
var ROLES = {
  SUPER_ADMIN: "SUPER_ADMIN",
  ADMIN: "ADMIN",
  COUNCIL_MEMBER: "COUNCIL_MEMBER",
  TREASURER: "TREASURER",
  CLERGY: "CLERGY",
  MINISTRY_COORDINATOR: "MINISTRY_COORDINATOR",
  STAFF: "STAFF",
  MEMBER: "MEMBER",
  GUEST: "GUEST"
};
var ROLE_LABELS = {
  [ROLES.SUPER_ADMIN]: "Super Admin",
  [ROLES.ADMIN]: "Church Administrator",
  [ROLES.COUNCIL_MEMBER]: "Council Member",
  [ROLES.TREASURER]: "Treasurer",
  [ROLES.CLERGY]: "Clergy / Vicar",
  [ROLES.MINISTRY_COORDINATOR]: "Ministry Coordinator",
  [ROLES.STAFF]: "Staff / Secretary",
  [ROLES.MEMBER]: "Member",
  [ROLES.GUEST]: "Guest"
};
var ACCESS_MATRIX = {
  documents: {
    [ROLES.SUPER_ADMIN]: "CRUD_APPROVE",
    [ROLES.ADMIN]: "CRUD",
    [ROLES.COUNCIL_MEMBER]: "READ_APPROVE",
    [ROLES.TREASURER]: "READ",
    [ROLES.CLERGY]: "CRUD_APPROVE",
    [ROLES.MINISTRY_COORDINATOR]: "CR_SCOPED",
    [ROLES.STAFF]: "CRU",
    [ROLES.MEMBER]: "NONE",
    [ROLES.GUEST]: "NONE"
  },
  ministry: {
    [ROLES.SUPER_ADMIN]: "CRUD",
    [ROLES.ADMIN]: "READ",
    [ROLES.COUNCIL_MEMBER]: "CRU",
    [ROLES.TREASURER]: "READ",
    [ROLES.CLERGY]: "CRUD",
    [ROLES.MINISTRY_COORDINATOR]: "CRUD_SCOPED",
    [ROLES.STAFF]: "READ",
    [ROLES.MEMBER]: "NONE",
    [ROLES.GUEST]: "NONE"
  },
  personnel: {
    [ROLES.SUPER_ADMIN]: "CRUD",
    [ROLES.ADMIN]: "CRUD",
    [ROLES.COUNCIL_MEMBER]: "READ",
    [ROLES.TREASURER]: "READ",
    [ROLES.CLERGY]: "CRU",
    [ROLES.MINISTRY_COORDINATOR]: "READ",
    [ROLES.STAFF]: "READ",
    [ROLES.MEMBER]: "NONE",
    [ROLES.GUEST]: "NONE"
  },
  financial: {
    [ROLES.SUPER_ADMIN]: "CRUD",
    [ROLES.ADMIN]: "CRUD",
    [ROLES.COUNCIL_MEMBER]: "READ",
    [ROLES.TREASURER]: "CRUD",
    [ROLES.CLERGY]: "READ",
    [ROLES.MINISTRY_COORDINATOR]: "READ",
    [ROLES.STAFF]: "READ",
    [ROLES.MEMBER]: "NONE",
    [ROLES.GUEST]: "NONE"
  },
  events: {
    [ROLES.SUPER_ADMIN]: "CRUD",
    [ROLES.ADMIN]: "CRUD",
    [ROLES.COUNCIL_MEMBER]: "CRU",
    [ROLES.TREASURER]: "READ",
    [ROLES.CLERGY]: "CRUD",
    [ROLES.MINISTRY_COORDINATOR]: "CRUD_SCOPED",
    [ROLES.STAFF]: "CR",
    [ROLES.MEMBER]: "READ",
    [ROLES.GUEST]: "READ"
  },
  reports: {
    [ROLES.SUPER_ADMIN]: "CRUD",
    [ROLES.ADMIN]: "CRUD",
    [ROLES.COUNCIL_MEMBER]: "READ",
    [ROLES.TREASURER]: "CRUD",
    [ROLES.CLERGY]: "READ",
    [ROLES.MINISTRY_COORDINATOR]: "READ_SCOPED",
    [ROLES.STAFF]: "READ",
    [ROLES.MEMBER]: "NONE",
    [ROLES.GUEST]: "NONE"
  },
  settings: {
    [ROLES.SUPER_ADMIN]: "CRUD",
    [ROLES.ADMIN]: "CRU",
    [ROLES.COUNCIL_MEMBER]: "NONE",
    [ROLES.TREASURER]: "NONE",
    [ROLES.CLERGY]: "READ",
    [ROLES.MINISTRY_COORDINATOR]: "NONE",
    [ROLES.STAFF]: "NONE",
    [ROLES.MEMBER]: "NONE",
    [ROLES.GUEST]: "NONE"
  }
};

// netlify/functions/bootstrap-admin.js
var bootstrap_admin_default = async (req) => {
  try {
    if (req.method !== "POST") {
      return jsonResponse({ error: "Method not allowed" }, 405);
    }
    const expected = process.env.BOOTSTRAP_SECRET;
    if (!expected) {
      throw new ForbiddenError(
        "Bootstrap is not configured. Set BOOTSTRAP_SECRET in your Netlify environment variables first, then redeploy."
      );
    }
    const body = await req.json();
    const { email, role, secret, password } = body;
    if (secret !== expected) {
      throw new ForbiddenError("Invalid bootstrap secret.");
    }
    if (!email || !email.trim()) {
      throw new ValidationError("Email is required.");
    }
    if (!Object.values(ROLES).includes(role)) {
      throw new ValidationError(`Role must be one of: ${Object.values(ROLES).join(", ")}`);
    }
    if (password != null && password.length < 8) {
      throw new ValidationError("Password must be at least 8 characters.");
    }
    const users = await admin.listUsers();
    const user = users.find((u) => u.email?.toLowerCase() === email.toLowerCase());
    if (!user) {
      throw new NotFoundError(
        `No Identity account found for ${email}. Create/confirm the account in Netlify Identity first, then try again.`
      );
    }
    const updates = { app_metadata: { roles: [role] } };
    if (password != null) {
      updates.password = password;
      updates.confirm = true;
    }
    const updated = await admin.updateUser(user.id, updates);
    return jsonResponse({
      success: true,
      id: updated.id,
      email: updated.email,
      role: updated.roles?.[0] ?? null,
      passwordSet: password != null
    });
  } catch (err) {
    return errorResponse(err);
  }
};
var config = { path: "/api/bootstrap-admin" };
export {
  config,
  bootstrap_admin_default as default
};
